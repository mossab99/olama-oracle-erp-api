import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    ORACLE_HOST = os.getenv("ORACLE_HOST", "192.168.0.118")
    ORACLE_PORT = int(os.getenv("ORACLE_PORT", "1521"))
    ORACLE_SID = os.getenv("ORACLE_SID", "ORCL")
    ORACLE_USER = os.getenv("ORACLE_USER", "DEMO")
    ORACLE_PASSWORD = os.getenv("ORACLE_PASSWORD", "")

    CURRENT_YEAR = os.getenv("CURRENT_YEAR", "2025/2026")

    API_SECRET_KEY = os.getenv("API_SECRET_KEY", "change-this-secret-key")
    API_HOST = os.getenv("API_HOST", "0.0.0.0")
    API_PORT = int(os.getenv("API_PORT", "5000"))

    ORACLE_CLIENT_DIR = os.getenv("ORACLE_CLIENT_DIR", "")
