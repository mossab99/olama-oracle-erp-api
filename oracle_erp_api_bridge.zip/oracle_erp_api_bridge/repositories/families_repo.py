from db import query_all, query_one
from config import Config


def get_all_families():
    """
    Replace FAMILIES and its columns with the real Oracle ERP table/column names.
    """
    sql = """
        SELECT
            f.ID AS family_id,
            f.FAMILY_NAME AS family_name,
            f.FATHER_NAME AS father_name,
            f.MOTHER_NAME AS mother_name,
            f.MOBILE AS mobile,
            f.STATUS AS status
        FROM FAMILIES f
        WHERE f.STATUS = 'ACTIVE'
        ORDER BY f.FAMILY_NAME
    """

    return query_all(sql)


def get_family_by_id(family_id):
    """
    Replace FAMILIES and its columns with the real Oracle ERP table/column names.
    """
    sql = """
        SELECT
            f.ID AS family_id,
            f.FAMILY_NAME AS family_name,
            f.FATHER_NAME AS father_name,
            f.MOTHER_NAME AS mother_name,
            f.MOBILE AS mobile,
            f.STATUS AS status
        FROM FAMILIES f
        WHERE f.ID = :family_id
    """

    return query_one(sql, {
        "family_id": family_id
    })


def get_students_by_family_id(family_id):
    """
    Replace STUDENTS and its columns with the real Oracle ERP table/column names.
    """
    sql = """
        SELECT
            s.ID AS student_id,
            s.FAMILY_ID AS family_id,
            s.STUDENT_NAME AS student_name,
            s.GRADE_NAME AS grade_name,
            s.SECTION_NAME AS section_name,
            s.ACADEMIC_YEAR AS academic_year,
            s.STATUS AS status
        FROM STUDENTS s
        WHERE s.FAMILY_ID = :family_id
          AND s.ACADEMIC_YEAR = :current_year
          AND s.STATUS = 'ACTIVE'
        ORDER BY s.STUDENT_NAME
    """

    return query_all(sql, {
        "family_id": family_id,
        "current_year": Config.CURRENT_YEAR
    })
