from db import query_all, query_one
from config import Config


def get_all_students():
    """
    Replace STUDENTS and its columns with the real Oracle ERP table/column names.
    """
    sql = """
        SELECT
            s.ID AS student_id,
            s.FAMILY_ID AS family_id,
            s.STUDENT_NAME AS student_name,
            s.GRADE_NAME AS grade_name,
            s.SECTION_NAME AS section_name,
            s.ACADEMIC_YEAR AS academic_year,
            s.STATUS AS status
        FROM STUDENTS s
        WHERE s.ACADEMIC_YEAR = :current_year
          AND s.STATUS = 'ACTIVE'
        ORDER BY s.GRADE_NAME, s.SECTION_NAME, s.STUDENT_NAME
    """

    return query_all(sql, {
        "current_year": Config.CURRENT_YEAR
    })


def get_student_by_id(student_id):
    """
    Replace STUDENTS and its columns with the real Oracle ERP table/column names.
    """
    sql = """
        SELECT
            s.ID AS student_id,
            s.FAMILY_ID AS family_id,
            s.STUDENT_NAME AS student_name,
            s.GRADE_NAME AS grade_name,
            s.SECTION_NAME AS section_name,
            s.ACADEMIC_YEAR AS academic_year,
            s.STATUS AS status
        FROM STUDENTS s
        WHERE s.ID = :student_id
    """

    return query_one(sql, {
        "student_id": student_id
    })


def search_students(search_text):
    """
    Replace STUDENTS and its columns with the real Oracle ERP table/column names.
    """
    sql = """
        SELECT
            s.ID AS student_id,
            s.FAMILY_ID AS family_id,
            s.STUDENT_NAME AS student_name,
            s.GRADE_NAME AS grade_name,
            s.SECTION_NAME AS section_name,
            s.ACADEMIC_YEAR AS academic_year,
            s.STATUS AS status
        FROM STUDENTS s
        WHERE s.ACADEMIC_YEAR = :current_year
          AND s.STATUS = 'ACTIVE'
          AND LOWER(s.STUDENT_NAME) LIKE LOWER(:search_text)
        ORDER BY s.STUDENT_NAME
    """

    return query_all(sql, {
        "current_year": Config.CURRENT_YEAR,
        "search_text": f"%{search_text}%"
    })
