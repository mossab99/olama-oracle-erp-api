import oracledb
from config import Config


_oracle_client_initialized = False


def init_oracle_client():
    """
    Initializes Oracle Thick Mode.

    This is normally required for Oracle 11g.
    Make sure Oracle Instant Client is installed and ORACLE_CLIENT_DIR is correct.
    """
    global _oracle_client_initialized

    if _oracle_client_initialized:
        return

    if Config.ORACLE_CLIENT_DIR:
        oracledb.init_oracle_client(lib_dir=Config.ORACLE_CLIENT_DIR)
    else:
        # If ORACLE_CLIENT_DIR is empty, the Oracle client folder must be in PATH.
        oracledb.init_oracle_client()

    _oracle_client_initialized = True


def get_dsn():
    return oracledb.makedsn(
        Config.ORACLE_HOST,
        Config.ORACLE_PORT,
        sid=Config.ORACLE_SID
    )


def get_connection():
    init_oracle_client()

    return oracledb.connect(
        user=Config.ORACLE_USER,
        password=Config.ORACLE_PASSWORD,
        dsn=get_dsn()
    )


def rows_to_dicts(cursor, rows):
    columns = [col[0].lower() for col in cursor.description]
    return [dict(zip(columns, row)) for row in rows]


def query_all(sql, params=None):
    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql, params or {})
        rows = cursor.fetchall()
        return rows_to_dicts(cursor, rows)

    finally:
        cursor.close()
        conn.close()


def query_one(sql, params=None):
    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute(sql, params or {})
        row = cursor.fetchone()

        if not row:
            return None

        columns = [col[0].lower() for col in cursor.description]
        return dict(zip(columns, row))

    finally:
        cursor.close()
        conn.close()
